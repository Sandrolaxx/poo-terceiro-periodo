package util;

import entidades.Cliente;
import entidades.Quarto;
import entidades.Reserva;

import java.lang.reflect.Array;
import java.util.Arrays;
import java.util.Date;

public class ArrayUtil {

    //Array de quartos
    public static Quarto[] adicionar(Quarto[] array, Quarto quarto) {
        if(Arrays.stream(array).count() == array.length ){
            array = expandirArray(array);
        }
        for(int i = 0; i< array.length; i++){
            if(array[i] == null){
                array[i] = quarto;
                break;
            }
        }
        return array;
    }

    private static Quarto[] expandirArray(Quarto[] array){
        return Arrays.copyOf(array, array.length + 1);
    }


    //Array de reservas
    public static Reserva[] adicionar(Reserva[] array, Reserva reserva) {
        Reserva[] novoArray = Arrays.copyOf(array, array.length + 1);
        novoArray[array.length] = reserva;
        return novoArray;
    }

    //Array de Clientes
    public static Cliente[] adicionar(Cliente[] array, Cliente cliente) {
        if(Arrays.stream(array).count() == array.length ){
            array = expandirArray(array);
        }
        for(int i = 0; i< array.length; i++){
            if(array[i] == null){
                array[i] = cliente;
                break;
            }
        }
        return array;
    }

    private static Cliente[] expandirArray(Cliente[] array){
        return Arrays.copyOf(array, array.length + 1);
    }
}
