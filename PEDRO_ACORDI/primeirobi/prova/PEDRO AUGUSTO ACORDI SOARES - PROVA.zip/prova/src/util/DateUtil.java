package util;

public class DateUtil {
    public static long SEGUNDO = 1000;
    public static long MINUTO = 60 * SEGUNDO;
    public static long HORA = 60 * MINUTO;
    public static long DIA = 24 * HORA;
}
